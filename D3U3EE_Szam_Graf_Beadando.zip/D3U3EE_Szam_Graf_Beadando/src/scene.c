#include "scene.h"

#include <obj/load.h>
#include <obj/draw.h>

void init_scene(Scene* scene)
{
   
	load_model(&(scene->body), "assets/models/body.obj");
	scene->bodytexture = load_texture("assets/textures/plane.jpg");
	
	load_model(&(scene->rotor), "assets/models/rotor.obj");
	scene->rotortexture = load_texture("assets/textures/rotor.jpg");
	
	load_model(&(scene->sky), "assets/models/sky.obj");
	scene->skytexture = load_texture("assets/textures/sky.jpg");
	
	load_model(&(scene->elevator_right), "assets/models/elevator_right.obj"); 
	
	load_model(&(scene->elevator_left), "assets/models/elevator_left.obj"); 
	load_model(&(scene->rudder), "assets/models/rudder.obj");
	
    //scene->texture_id = load_texture("assets/textures/plane.png");

    //glBindTexture(GL_TEXTURE_2D, scene->texture_id);

    scene->material.ambient.red = 1.0;
    scene->material.ambient.green = 1.0;
    scene->material.ambient.blue = 1.0;

    scene->material.diffuse.red = 1.0;
    scene->material.diffuse.green = 1.0;
    scene->material.diffuse.blue = 1.0;

    scene->material.specular.red = 0.0;
    scene->material.specular.green = 0.0;
    scene->material.specular.blue = 0.0;

    scene->material.shininess = 60.0;
	
	scene->rotorforgas.x=0.0; // vec3 kinullázáása
	scene->rotorforgas.y=0.0;
	scene->rotorforgas.z=0.0;
	
	scene->plane_position.z=0.0;
	scene->plane_position.x=0.0;
	scene->plane_position.y=0.0;
	
	scene->plane_speed.y=0.0;
	scene->plane_speed.x=0.0;
	scene->plane_speed.z=0.0;
	
	scene->plane_rotation.y=0.0;
	scene->plane_rotation.x=0.0;
	scene->plane_rotation.z=0.0;
	
	scene->plane_rotation_speed.y=0.0;
	scene->plane_rotation_speed.x=0.0;
	scene->plane_rotation_speed.z=0.0;
	
	
	scene->elevators_rotation.y=0.0;
	scene->elevators_rotation.x=0.0;
	scene->elevators_rotation.z=0.0;
	
	scene->elevators_rotation_speed.y=0.0;
	scene->elevators_rotation_speed.x=0.0;
	scene->elevators_rotation_speed.z=0.0;

	
	scene->rudder_rotation.y=0.0;
	scene->rudder_rotation.x=0.0;
	scene->rudder_rotation.z=0.0;
	
	scene->rudder_rotation_speed.y=0.0;
	scene->rudder_rotation_speed.x=0.0;
	scene->rudder_rotation_speed.z=0.0;
	
	scene->HelpMenuTexture = load_texture("assets/textures/helper2.jpg");
}

void set_lighting()
{
    float ambient_light[] = { 100.0f, 0.3f, 0.3f, 1.0f };
    float diffuse_light[] = { 1.0f, 1.0f, 1.0, 1.0f };
    float specular_light[] = { 1.0f, 0.0f, 0.0f, 1.0f };
    float position[] = { 1.0f, 20.0f, 100.0f, 1.0f };

    glLightfv(GL_LIGHT0, GL_AMBIENT, ambient_light);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse_light);
    glLightfv(GL_LIGHT0, GL_SPECULAR, specular_light);
    glLightfv(GL_LIGHT0, GL_POSITION, position);
}

void set_material(const Material* material)
{
    float ambient_material_color[] = {
        material->ambient.red,
        material->ambient.green,
        material->ambient.blue
    };

    float diffuse_material_color[] = {
        material->diffuse.red,
        material->diffuse.green,
        material->diffuse.blue
    };

    float specular_material_color[] = {
        material->specular.red,
        material->specular.green,
        material->specular.blue
    };

    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, ambient_material_color);
    glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, diffuse_material_color);
    glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, specular_material_color);

    glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, &(material->shininess));
}

void update_scene(Scene* scene, double time, Camera* camera)
{
	scene->rotorforgas.y +=10; //fgv segítsgévével rotet app.c meghívása
	
	scene->plane_position.y += scene->plane_speed.y*time; //test mozgatasa
	
	scene->elevators_rotation.x+= scene->elevators_rotation_speed.x*time; //elevators mozgatása
	
	scene->rudder_rotation.z+= scene->rudder_rotation_speed.z*time; //rudder mozgatása
	
	
	scene->plane_position.x += scene->plane_speed.x*time;
	camera->position.y+= scene->plane_speed.y*time;
	camera->position.x+= scene->plane_speed.x*time; //kamera mozgása a testtel
	
	scene->plane_rotation.y += scene->plane_rotation_speed.y*time;
	scene->plane_rotation.x += scene->plane_rotation_speed.x*time;
}

void render_scene(const Scene* scene)
{

    set_material(&(scene->material));
    set_lighting();
	glBindTexture(GL_TEXTURE_2D, scene->skytexture);
	draw_model(&(scene->sky));
	
	
	
	glPushMatrix();
		glTranslatef(scene->plane_position.x, scene->plane_position.y, scene->plane_position.z);
		glRotatef(scene->plane_rotation.y,0,1,0); //repülő forgatás
		glRotatef(scene->plane_rotation.x,1,0,0);
		glPushMatrix();
	
			glRotatef(scene->rotorforgas.y,0,1,0);				//rotor forgatás mit milyen irányba
			glBindTexture(GL_TEXTURE_2D, scene->rotortexture);  //textura meghivas
			draw_model(&(scene->rotor));	// obj meghívás
		glPopMatrix();
	
		glPushMatrix();
			glBindTexture(GL_TEXTURE_2D, scene->bodytexture);
			draw_model(&(scene->body));
	
		glPopMatrix();
		
		
		glPushMatrix();
			glTranslatef(1.8,-11.1,0.211);
			glRotatef(scene->elevators_rotation.x,1,0,0);//   bal elevators forgatása ilyen irányba
			glBindTexture(GL_TEXTURE_2D, scene->rotortexture);
			draw_model(&(scene->elevator_right)); 
		glPopMatrix();
		
		glPushMatrix();
			glTranslatef(-1.75,-11.1,0.211);
			glRotatef(scene->elevators_rotation.x,1,0,0);
			glBindTexture(GL_TEXTURE_2D, scene->rotortexture); // jobb  elevators forgatása ilyen irányba
			draw_model(&(scene->elevator_left)); 
		glPopMatrix();
		
		glPushMatrix();
			glTranslatef(0.01,-11.31,1.2); //rudder elhelyezkedése
			glRotatef(scene->rudder_rotation.z,0,0,1);// rudder forgatása ilyen irányba
			glBindTexture(GL_TEXTURE_2D, scene->rotortexture);
			draw_model(&(scene->rudder)); 
		glPopMatrix();
		
		
	glPopMatrix();
	
	//glTranslatef(0,300,0)

		if(scene->HelpMenuOn){
		loadHelpMenu(scene->HelpMenuTexture);
		}
}

void draw_origin()
{
    glBegin(GL_LINES);

    glColor3f(1, 0, 0);
    glVertex3f(0, 0, 0);
    glVertex3f(1, 0, 0);

    glColor3f(0, 1, 0);
    glVertex3f(0, 0, 0);
    glVertex3f(0, 1, 0);

    glColor3f(0, 0, 1);
    glVertex3f(0, 0, 0);
    glVertex3f(0, 0, 1);

    glEnd();
}



void loadHelpMenu(GLuint control) {
    glDisable(GL_LIGHTING);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
    glBindTexture(GL_TEXTURE_2D, control);

    glBegin(GL_QUADS);
    glTexCoord2f(0, 0);
    glVertex3d(-4, 3, -5);

    glTexCoord2f(1, 0);
    glVertex3d(4, 3, -5);

    glTexCoord2f(1, 1);
    glVertex3d(4, -3, -5);

    glTexCoord2f(0, 1);
    glVertex3d(-4, -3, -5);
    glEnd();

    glEnable(GL_LIGHTING);
}

void set_HelpMenuState(Scene* scene,bool state){
scene->HelpMenuOn = state;

}