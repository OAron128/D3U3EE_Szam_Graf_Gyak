#ifndef SCENE_H
#define SCENE_H

#include "camera.h"
#include "texture.h"

#include <obj/model.h>

typedef struct Scene
{
    Model rotor;
	Model body;
	Model sky;
	
	Model elevator_right;
	Model elevator_left;
	Model rudder;
	
    Material material;
    GLuint bodytexture;
	GLuint rotortexture;
	GLuint skytexture;
	vec3 rotorforgas;  // declarálás
	
	vec3 plane_position;
	vec3 plane_speed;
	
	vec3 plane_rotation;
	vec3 plane_rotation_speed;
	
	
	vec3 elevators_rotation; // jobb és bal lapát mozgatása fel le irányba
	vec3 elevators_rotation_speed;

	vec3 rudder_rotation; // felső lapát jobbra és balra mozgatása
	vec3 rudder_rotation_speed;
	
	bool HelpMenuOn;
	
	GLuint HelpMenuTexture;
	
} Scene;

/**
 * Initialize the scene by loading models.
 */
void init_scene(Scene* scene);

/**
 * Set the lighting of the scene.
 */
void set_lighting();

/**
 * Set the current material.
 */
void set_material(const Material* material);

/**
 * Update the scene.
 */
void update_scene(Scene* scene, double time, Camera * camera);

/**
 * Render the scene objects.
 */
void render_scene(const Scene* scene);

/**
 * Draw the origin of the world coordinate system.
 */
void draw_origin();

//void set_plane_moving_speed(Scence* scene, double speed);  //obj mozgatasa

void set_HelpMenuState(Scene* scene,bool state);




#endif /* SCENE_H */


