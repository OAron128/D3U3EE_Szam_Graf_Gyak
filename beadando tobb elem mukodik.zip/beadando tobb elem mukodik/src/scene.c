#include "scene.h"

#include <obj/load.h>
#include <obj/draw.h>

void init_scene(Scene* scene)
{
   
	load_model(&(scene->body), "assets/models/body.obj");
	scene->bodytexture = load_texture("assets/textures/plane.jpg");
	
	load_model(&(scene->rotor), "assets/models/rotor.obj");
	scene->rotortexture = load_texture("assets/textures/rotor.jpg");
	
	load_model(&(scene->sky), "assets/models/sky.obj");
	scene->skytexture = load_texture("assets/textures/sky.jpg");
	
	//load_model(&(scene->elevator_right), "assets/models/elevater_right.obj"); //ez a modell nem jó
	//load_model(&(scene->elevator_left), "assets/models/elevater_left.obj"); //ez sem jó
	//load_model(&(scene->rudder), "assets/models/rudder.obj");
	
    //scene->texture_id = load_texture("assets/textures/plane.png");

    //glBindTexture(GL_TEXTURE_2D, scene->texture_id);

    scene->material.ambient.red = 1.0;
    scene->material.ambient.green = 1.0;
    scene->material.ambient.blue = 1.0;

    scene->material.diffuse.red = 1.0;
    scene->material.diffuse.green = 1.0;
    scene->material.diffuse.blue = 1.0;

    scene->material.specular.red = 0.0;
    scene->material.specular.green = 0.0;
    scene->material.specular.blue = 0.0;

    scene->material.shininess = 60.0;
	
	scene->rotorforgas.x=0.0; // vec3 kinullázáása
	scene->rotorforgas.y=0.0;
	scene->rotorforgas.z=0.0;
	
}

void set_lighting()
{
    float ambient_light[] = { 100.0f, 0.3f, 0.3f, 1.0f };
    float diffuse_light[] = { 1.0f, 1.0f, 1.0, 1.0f };
    float specular_light[] = { 1.0f, 0.0f, 0.0f, 1.0f };
    float position[] = { 1.0f, 20.0f, 100.0f, 1.0f };

    glLightfv(GL_LIGHT0, GL_AMBIENT, ambient_light);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse_light);
    glLightfv(GL_LIGHT0, GL_SPECULAR, specular_light);
    glLightfv(GL_LIGHT0, GL_POSITION, position);
}

void set_material(const Material* material)
{
    float ambient_material_color[] = {
        material->ambient.red,
        material->ambient.green,
        material->ambient.blue
    };

    float diffuse_material_color[] = {
        material->diffuse.red,
        material->diffuse.green,
        material->diffuse.blue
    };

    float specular_material_color[] = {
        material->specular.red,
        material->specular.green,
        material->specular.blue
    };

    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, ambient_material_color);
    glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, diffuse_material_color);
    glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, specular_material_color);

    glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, &(material->shininess));
}

void update_scene(Scene* scene)
{
	scene->rotorforgas.y +=40;
									//fgv segítsgévével rotet app.c meghívása
}

void render_scene(const Scene* scene)
{
    set_material(&(scene->material));
    set_lighting();
	glBindTexture(GL_TEXTURE_2D, scene->skytexture);
	draw_model(&(scene->sky));
	
	glPushMatrix();
	glRotatef(scene->rotorforgas.y,0,1,0);				//rotor forgatás mit milyen irányba
	glBindTexture(GL_TEXTURE_2D, scene->rotortexture);  //textura meghivas
    draw_model(&(scene->rotor));						// obj meghívás
	glPopMatrix();
	
	
	
	glBindTexture(GL_TEXTURE_2D, scene->bodytexture);
	draw_model(&(scene->body));
	
	
	
	//draw_model(&(scene->elevator_right));  // ez nem jó
	//draw_model(&(scene->elevater_left)); //ez nem jó
	//glTranslatef(0,300,0)
	//draw_model(&(scene->rudder));
	
}

void draw_origin()
{
    glBegin(GL_LINES);

    glColor3f(1, 0, 0);
    glVertex3f(0, 0, 0);
    glVertex3f(1, 0, 0);

    glColor3f(0, 1, 0);
    glVertex3f(0, 0, 0);
    glVertex3f(0, 1, 0);

    glColor3f(0, 0, 1);
    glVertex3f(0, 0, 0);
    glVertex3f(0, 0, 1);

    glEnd();
}
